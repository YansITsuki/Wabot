exports.gameMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 MENU GAME 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}limitgame
き⃟🌊. ${prefix}slot
き⃟🌊. ${prefix}siapaaku
き⃟🌊. ${prefix}family100
き⃟🌊. ${prefix}kuismath
き⃟🌊. ${prefix}asahotak
き⃟🌊. ${prefix}tebaklirik
き⃟🌊. ${prefix}tebaklagu
き⃟🌊. ${prefix}susunkata
き⃟🌊. ${prefix}kimiakuis
き⃟🌊. ${prefix}caklontong
き⃟🌊. ${prefix}tebakjenaka
き⃟🌊. ${prefix}tebakanime
き⃟🌊. ${prefix}tebakgambar
き⃟🌊. ${prefix}tebaktebakan
き⃟🌊. ${prefix}tebakumur
き⃟🌊. ${prefix}suit
き⃟🌊. ${prefix}math

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.funMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 FUN MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}mining
き⃟🌊. ${prefix}cekwatak _nama_
き⃟🌊. ${prefix}cekmati _nama_
き⃟🌊. ${prefix}wangy _nama_
き⃟🌊. ${prefix}citacita
き⃟🌊. ${prefix}toxic
き⃟🌊. ${prefix}truth
き⃟🌊. ${prefix}dare
き⃟🌊. ${prefix}apakah _teks_
き⃟🌊. ${prefix}bisakah _teks_
き⃟🌊. ${prefix}kapankah _teks_
き⃟🌊. ${prefix}rate

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.otherMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 OTHER MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}cerpen
き⃟🌊. ${prefix}brainly _query_
き⃟🌊. ${prefix}shopee _query_
き⃟🌊. ${prefix}playstore _query_
き⃟🌊. ${prefix}ssweb _query_
き⃟🌊. ${prefix}google _query_
き⃟🌊. ${prefix}image _query_
き⃟🌊. ${prefix}pinterest _query_
き⃟🌊. ${prefix}nulis
き⃟🌊. ${prefix}igstalk
き⃟🌊. ${prefix}iguser
き⃟🌊. ${prefix}githubstalk
き⃟🌊. ${prefix}tiktokstalk
き⃟🌊. ${prefix}img2url _reply image_
き⃟🌊. ${prefix}ytsearch _query_

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.stickerMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 STICKER MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}attp _teks_
き⃟🌊. ${prefix}ttp2 _teks_
き⃟🌊. ${prefix}ttp3 _teks_
き⃟🌊. ${prefix}ttp4 _teks_
き⃟🌊. ${prefix}amongus _teks_
き⃟🌊. ${prefix}dadu
き⃟🌊. ${prefix}doge
き⃟🌊. ${prefix}patrick
き⃟🌊. ${prefix}gura
き⃟🌊. ${prefix}stickeranime
き⃟🌊. ${prefix}semoji _emoji_
き⃟🌊. ${prefix}sticker _reply image_
き⃟🌊. ${prefix}smeme _teks|teks_
き⃟🌊. ${prefix}swm _pack|author_
き⃟🌊. ${prefix}take _pack|author_
き⃟🌊. ${prefix}tovideo
き⃟🌊. ${prefix}toimg

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.ownerMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 OWNER MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}bc _teks_
き⃟🌊. ${prefix}term
き⃟🌊. ${prefix}eval
き⃟🌊. ${prefix}reset
き⃟🌊. ${prefix}clearall
き⃟🌊. ${prefix}leaveall
き⃟🌊. ${prefix}join _link_
き⃟🌊. ${prefix}shutdown
き⃟🌊. ${prefix}getquoted
き⃟🌊. ${prefix}addupdate _fitur_
き⃟🌊. ${prefix}exif _nama|author_
き⃟🌊. ${prefix}sewa add/del _waktu_
き⃟🌊. ${prefix}premium add _@tag|nomor_
き⃟🌊. ${prefix}premium del _@tag|nomor_

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}

exports.groupMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return`*「 GRUP MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}gelud _@tag_
き⃟🌊. ${prefix}tictactoe _@tag_
き⃟🌊. ${prefix}cekganteng
き⃟🌊. ${prefix}cekcantik
き⃟🌊. ${prefix}babi
き⃟🌊. ${prefix}beban
き⃟🌊. ${prefix}cantik
き⃟🌊. ${prefix}ganteng
き⃟🌊. ${prefix}groupsetting
き⃟🌊. ${prefix}afk _alasan_
き⃟🌊. ${prefix}ceksewa
き⃟🌊. ${prefix}kickall
き⃟🌊. ${prefix}infogroup
き⃟🌊. ${prefix}promote _@tag_
き⃟🌊. ${prefix}demote _@tag_
き⃟🌊. ${prefix}listonline
き⃟🌊. ${prefix}tagall _teks_
き⃟🌊. ${prefix}leave
き⃟🌊. ${prefix}kick _@tag_
き⃟🌊. ${prefix}add _+62xxx_
き⃟🌊. ${prefix}setnamegc
き⃟🌊. ${prefix}setppgc _reply image_
き⃟🌊. ${prefix}setdeskgc
き⃟🌊. ${prefix}sider _reply chat bot_
き⃟🌊. ${prefix}hidetag _teks_
き⃟🌊. ${prefix}linkgc

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.downloadMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
    return `*「 DOWNLOAD MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}fbdl
き⃟🌊. ${prefix}igdl
き⃟🌊. ${prefix}igdl2
き⃟🌊. ${prefix}twitter
き⃟🌊. ${prefix}tiktok
き⃟🌊. ${prefix}play _query_
き⃟🌊. ${prefix}ytmp3 _link
き⃟🌊. ${prefix}ytmp4_ink
き⃟🌊. ${prefix}ythd
き⃟🌊. ${prefix}soundcloud
き⃟🌊. ${prefix}tiktoknowm _link_
き⃟🌊. ${prefix}tiktokaudio
き⃟🌊. ${prefix}mediafire

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.rulesBot = (prefix) => {
    return `*「 RULES 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙 」*
*Username :* ${pushname}


1. Jangan Toxic Ke Bot. 
Sanksi: *PERMANENT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*

3. Jangan Spam Fitur Bot.
Sanksi: *PERMANENT BLOCK*

4. Jangan Culik Sembarangan.
Sanksi: *VERY HARD BLOCK*

*Jika sudah dipahami rules-nya,*
*Silahkan ketik ${prefix}menu untuk memulai!*
Mengterima kasih.
`
}
exports.iklanBot = (prefix) => {
return`         𝗜𝗞𝗟𝗔𝗡 𝗕𝗢𝗧𝗭
      
KEUNTUNGAN BOTZ
▢ BISA JAGA GRUP DARI LINK
▢ BISA BIKIN STIKER TEKS,VIDIO DAN GAMBAR
▢ BISA NYAPA TAMU YG MASUK
▢ BISA PLAY AUDIO DAN VIDIO
▢ BISA JADI ADMIN BERBER

KELEBIHAN BOTZ
▢ ON 24JAM KALAU GK DELAY
▢ SELALU UPDATE FITUR 
▢ BOT NO PASARAN

LIST HARGA SEWA BOTZ
▢ PERHARI 3K
▢ PERMINGGU 10K
▢ PERBULAN 15K
▢ PERMANEN 20K
MINAT HIBUNGI OWNER
wa.me/6285727492435

YG MAU TOP UP GAME MARI JOIN
https://chat.whatsapp.com/GQJ5YYly5UFEsqRS9FZH0e`
}
exports.infoMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return `*「 INFO MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}update
き⃟🌊. ${prefix}level
き⃟🌊. ${prefix}rules
き⃟🌊. ${prefix}profile
き⃟🌊. ${prefix}waktu
き⃟🌊. ${prefix}botstat
き⃟🌊. ${prefix}sewabot
き⃟🌊. ${prefix}listsewa
き⃟🌊. ${prefix}owner
き⃟🌊. ${prefix}ping
き⃟🌊. ${prefix}runtime
き⃟🌊. ${prefix}donasi
き⃟🌊. ${prefix}listdm
き⃟🌊. ${prefix}leaderboard
き⃟🌊. ${prefix}cekpremium
き⃟🌊. ${prefix}listpremium
き⃟🌊. ${prefix}getpp
き⃟🌊. ${prefix}setpp _reply image_
き⃟🌊. ${prefix}bugreport _keluhan_

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
} 
exports.islamMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return `*「 ISLAM MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}kisahnabi
き⃟🌊. ${prefix}jadwalsholat
き⃟🌊. ${prefix}alquran
き⃟🌊. ${prefix}asmaulhusna
き⃟🌊. ${prefix}alquranaudio
き⃟🌊. ${prefix}listsurah

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝑿𝒓𝒖𝒕𝒛 𝑶𝒇𝒇𝒊??𝒊𝒂𝒍
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.sertiMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return `*「 SERTI MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}sertitolol
き⃟🌊. ${prefix}bucinserti
き⃟🌊. ${prefix}fuckboy
き⃟🌊. ${prefix}fuckgirl
き⃟🌊. ${prefix}badboy
き⃟🌊. ${prefix}badgirl
き⃟🌊. ${prefix}goodboy
き⃟🌊. ${prefix}goodgirl

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.ceritaMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return`*「 CERITA MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}cerpen
き⃟🌊. ${prefix}horor
き⃟🌊. ${prefix}quotsdilan
き⃟🌊. ${prefix}pantun
き⃟🌊. ${prefix}faktaunik
き⃟🌊. ${prefix}bucin
き⃟🌊. ${prefix}quotesanime
き⃟🌊. ${prefix}quotes

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.makerMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return`*「 MAKER MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}tahta
き⃟🌊. ${prefix}cup
き⃟🌊. ${prefix}cup1
き⃟🌊. ${prefix}coffe
き⃟🌊. ${prefix}birthdaycake
き⃟🌊. ${prefix}metallogo
き⃟🌊. ${prefix}lighttext
き⃟🌊. ${prefix}halloween
き⃟🌊. ${prefix}vampire
き⃟🌊. ${prefix}matrix
き⃟🌊. ${prefix}googletxt
き⃟🌊. ${prefix}spiderman
き⃟🌊. ${prefix}express

© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*
`
}
exports.toolsMenu = (prefix, pushname, isOwner, isPremium, baterai) => {
return`*「 TOOLS MENU 」*
*Username :* ${pushname}
*Status User :* ${isOwner ? 'Creator' : isPremium ? 'Premium' : 'Gratisan'}

き⃟🌊. ${prefix}addvn
き⃟🌊. ${prefix}listvn
き⃟🌊. ${prefix}getvn
き⃟🌊. ${prefix}addimg
き⃟🌊. ${prefix}listimg
き⃟🌊. ${prefix}addvid
き⃟🌊. ${prefix}listvid
き⃟🌊. ${prefix}addstik
き⃟🌊. ${prefix}liststik
き⃟🌊. ${prefix}getstik
   
© 𝑺𝑪 𝑶𝒓𝒊 𝒃𝒚 𝕯𝖊𝖓𝖆𝖗𝖆 𝕭𝖔𝖙
*Subs My Channel : Denara Bot*
*Ketik ${prefix}allmenu biar gak ribet xixi*`}